﻿Public Class OfficeStyle

End Class
