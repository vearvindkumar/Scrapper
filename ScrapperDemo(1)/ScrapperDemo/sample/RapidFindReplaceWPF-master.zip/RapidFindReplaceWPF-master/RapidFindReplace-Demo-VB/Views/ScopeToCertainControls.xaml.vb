﻿Public Class ScopeToCertainControls

End Class
